setwd('/Users/cuijiajun/Desktop/others/tmphernan/mapdamage/')
tablePs<-read.table(paste('/Users/cuijiajun/Desktop/others/tmphernan/mapdamage/','allinoneCtoT.txt',sep=''),header = F)

colnames(tablePs)<-c("pos" , "value"      ,   "group"    ,     "proportion", "pos_from_5end" ,"sample"   )

#ggplot
library(ggplot2)
ggplot(tablePs,aes(pos_from_5end,proportion,group=sample,color='#BA8921'))+geom_line()+(ylab('C to T Frequency'))+ theme_bw() + theme(panel.grid=element_blank())+scale_color_manual(values = c("#BA8921"))+theme(axis.text=element_text(size=12))
ggsave(paste('allinone','.png',sep=''),width = 10, height = 6)
#dfall[which(dfall$value>=0.0075),]

#input table of insert size
suppinsert<-read.table('/Users/cuijiajun/Desktop/others/maybeuseful/suppinsert_size.txt')

#ggplot plot the figures
ggplot(suppinsert,aes(suppinsert$V1))+geom_histogram(aes(y=..count../sum(..count..)),)+
  scale_y_continuous(labels = scales::percent_format())
ggsave('/Users/cuijiajun/Desktop/2022-2023_ucl_mres/Hernanlab/thesis_draft/imgs/insertlength_143.pdf')
                                                                                                                                                                                                                  