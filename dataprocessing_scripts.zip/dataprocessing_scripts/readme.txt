This folder contains the data processing pipelines and results. 

Four sub-folders:

Pipeline_preprocessing: The folder has the pipeline preprocessing raw data and extracting statistics from bam files.

longinsertsizein143Lapoz: The folder has one file to calculate long size insert molecular for 143 samples from Lapoz.

Mapdamage: The folder has two shell scripts running mapdamage reports for Pseudomonas and Arabidopsis thaliana and a R script to draw the figure 2b in thesis about the Ps mapdamage figure manually.

Dominance_strain_check: it contains a shell file to calculate the dominance strain mapped site number and an R script to draw the image.

