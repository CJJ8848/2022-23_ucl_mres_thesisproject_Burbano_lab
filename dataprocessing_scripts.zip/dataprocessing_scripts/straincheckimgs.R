
library(ggplot2)

#combine them together
samples=c('27.ESP_1975','30.ESP_1983b','33.ESP_1985b','34.ESP_1985c_S36','64.GBR_1933b_S36','75.LTU_1894_S30','76.LTU_2009_S19','109.NOR_1990','120.RUS_1860')
#samples=c('27.ESP_1975','30.ESP_1983b','33.ESP_1985b','34.ESP_1985c_S36','64.GBR_1933b_S36','75.LTU_1894_S30','76.LTU_2009_S19','86.NOR_1911_S7','109.NOR_1990','120.RUS_1860')
HBsamples=c('HB0737','HB0766','HB0814','HB0841','HB0828','HB0840'
            ,'HB0863')

n=0
p=list()
datas=data.frame()
wd<-'/Users/cuijiajun/Desktop/2022-2023_ucl_mres/Hernanlab/datapreprocessing/localstrainchecks/inputforRmodified_16_aftertrim/'
#install.packages('tidyverse')
library(tidyverse)
for (i in samples){
  print(i)
  dataraw<-read.table(paste(wd,"aftertrim_",i,"_straincheckmodified.txt.gz",sep = ''),header = T)
  dataraw$Sample<-i
  data<-count(dataraw[,c(10,11)],modifiedfreq)
  data$Sample<-i
  data$Proportion<-data$n/nrow(dataraw)
  datas<-rbind(datas,data)
}
for (i in HBsamples){
  print(i)
  dataraw<-read.table(paste(wd,"aftertrim_",i,"_straincheckmodified.txt.gz",sep = ''),header = T)
  dataraw$Sample<-i
  data<-count(dataraw[,c(10,11)],modifiedfreq)
  data$Sample<-i
  data$Proportion<-data$n/nrow(dataraw)
  datas<-rbind(datas,data)
}
nor <-datas
name='merge'

ggplot(datas,aes(x=modifiedfreq,y=Proportion))+geom_bar(aes(color=Sample), stat='identity',position = "identity")+scale_y_sqrt()+xlab('Folded alternative base Freq')+ylab('Proportion (square root)')+ggtitle('Folded alternative base Freq')#the proportion y axis
savepath='/Users/cuijiajun/Desktop/2022-2023_ucl_mres/Hernanlab/datapreprocessing/localstrainchecks/imgs/imgsmodified16/'
ggsave(paste(savepath,'100mereghistsqrt/',name,'.png',sep=''))


test<-head(nor)
summary(test$modifiedfreq)
# straincheckfinal
setwd('/Users/cuijiajun/Desktop/2022-2023_ucl_mres/Hernanlab/datapreprocessing/localstrainchecks/inputforRmodified_16_aftertrim/')

list <- list.files()
nor <- data.frame()
#savepath='/Users/cuijiajun/Desktop/strainchecks/imgs/imgsnomodified/'
#nor$X1stminfreq
savepath='/Users/cuijiajun/Desktop/2022-2023_ucl_mres/Hernanlab/datapreprocessing/localstrainchecks/imgs/imgsmodified16/'
for(i in list){
  path <- i
  nor <-read.table(path,header = T)
  name=strsplit(i,'_straincheckmodified')[[1]][1]
  ggplot(data = nor,aes(nor$modifiedfreq))+geom_histogram(aes(y = after_stat(count / sum(count))))+scale_y_sqrt()+ggtitle(name)+xlab('Folded alternative base Freq')+ylab('Proportion (square root)')#the proportion y axis
  ggsave(paste(savepath,'histsqrt/',name,'.png',sep=''))
}

