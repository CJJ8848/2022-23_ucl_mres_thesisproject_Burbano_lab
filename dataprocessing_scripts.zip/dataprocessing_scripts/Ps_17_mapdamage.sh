#!/bin/bash -l

#$ -l tmem=2G
#$ -l h_vmem=2G
#$ -l h_rt=20:00:0
#$ -wd /SAN/ugi/plant_genom/jiajucui/
#$ -V
#$ -e /SAN/ugi/plant_genom/jiajucui/logs/
#$ -o /SAN/ugi/plant_genom/jiajucui/logs/


#conda create -n  mapDamageR4
#conda activate mapdamageR4 and conda install -c conda-forge r-base=4.1 (4.2 or more is not supported) ref:https://github.com/rstudio/gt/issues/1004
#install mapDamage
#or not install the dep 5 R libs ref:https://ginolhac.github.io/mapDamage/#a1
#then use conda to install https://anaconda.org/bioconda/mapdamage2 
#conda install -c bioconda mapdamage2

#variables

i=${1}
samplename=$(cat /SAN/ugi/plant_genom/jiajucui/phylogeny/samplelist/ancient7.txt | sed -n $i'p')
#for 10 samples from Lapoz public sources
#samplename=$(cat /SAN/ugi/plant_genom/jiajucui/phylogeny/samplelist/ancient10.txt | sed -n $i'p')
wd=/SAN/ugi/plant_genom/jiajucui/phylogeny/phylogeny_snp/mapdamage/
refPs=/SAN/ugi/plant_genom/jiajucui/1_initial_data/reference_genome_Ps/Pseudomonas.OTU5_ref.fasta
source /home/jiajucui/tools/miniconda3/bin/activate mapdamageR4.1

cd ${wd}/usedforCFML_ps/

#echo "samplename: ${samplename}"  | tee -a ${wd}/md.log
mapDamage -i /SAN/ugi/plant_genom/jiajucui/4_mapping_to_pseudomonas/2023_37HB/${samplename}*q20.bam -r ${refPs}

#for 10 samples from Lapoz public sources
#mapDamage -i /SAN/ugi/plant_genom/jiajucui/4_mapping_to_pseudomonas/trimnstrimqualities10/${samplename}*q20.bam -r ${refPs}

mapDamage -d results*${samplename}* -y 0.05 --plot-only
echo 'md done'
