#!/bin/bash -l
#$ -l tmem=5G
#$ -l h_vmem=5G
#$ -l h_rt=20:00:0
#$ -N snp72tree 
#$ -pe smp 5
#$ -wd /SAN/ugi/plant_genom/jiajucui/
#$ -V
#$ -e /SAN/ugi/plant_genom/jiajucui/logs/
#$ -o /SAN/ugi/plant_genom/jiajucui/logs/
wd=/SAN/ugi/plant_genom/jiajucui/phylogeny/phylogeny_snp
cd ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/
source ~/tools/miniconda3/bin/activate phylogeny_snp

#merge
#/SAN/ugi/plant_genom/software/bcftools-1.11/bcftools merge ${wd}/vcfs/samples17_55_aftertrimnsqs10/*filtered.sorted.vcf.gz  -Oz -o ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/aftertrimnsqs_mergesnp_filtered.vcf.gz

#biallelic and non-variant (no multi after merge for CFML):
#should use bgzip for genome files like vcf and fasta
#/SAN/ugi/plant_genom/software/bcftools-1.11/bcftools view -M2 ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/aftertrimnsqs_mergesnp_filtered.vcf.gz | bgzip > ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/forCFML_aftertrimnsqs_nomulti_aftermerge_filtered.vcf.gz


#no need #convert merge vcf to phy to generate the fasta of nonandinvariant sites for CFML
#python /SAN/ugi/plant_genom/jiajucui/phylogeny/phylogeny_snp/vcf2phylip/vcf2phylip.py -i ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/forCFML_aftertrimnsqs_nomulti_aftermerge_filtered.vcf.gz -m 72
 
#biallelic only after merge:
#/SAN/ugi/plant_genom/software/bcftools-1.11/bcftools view -m2 -M2 ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/aftertrimnsqs_mergesnp_filtered.vcf.gz | bgzip > ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/aftertrimnsqs_bialleliconly_filtered.vcf.gz
# for vcf: 
#vim vcffile ad :%s/\/SAN\/ugi\/plant_genom\/jiajucui\/4_mapping_to_pseudomonas\/trimnstrimqualities10\///g
# and :% s/_removalAt_mapped_to_ps.sorted.q20.bam//g


#convert vcf to phy
#python /SAN/ugi/plant_genom/jiajucui/phylogeny/phylogeny_snp/vcf2phylip/vcf2phylip.py -i ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/aftertrimnsqs_bialleliconly_filtered.vcf.gz -m 72 | tee -a ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/tophy.log

source ~/tools/miniconda3/bin/activate r2t
#iqtree
cd ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/iqtree
#snp data tell the -m to use ASC
iqtree -T AUTO -s aftertrimnsqs_bialleliconly_filtered.min72.phy  -m MFP+ASC -B 1000 -alrt 1000 | tee -a ${wd}/phy/samples17_55_aftertrimnsqs/iqtree.log

#cd ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/rescalediqtree/
#rescale: {'A': 215675, 'C': 289763, 'T': 214219, 'G': 288534}
#strategy, completeness=1
#-fconst	Specify a list of comma-separated integer numbers. The number of entries should be equal to the number of states in the model (e.g. 4 for DNA and 20 for protein). IQ-TREE will then add a number of constant sites accordingly. For example, -fconst 10,20,15,40 will add 10 constant sites of all A, 20 constant sites of all C, 15 constant sites of all G and 40 constant sites of all T into the alignment.
#iqtree -fconst 215675,289763,288534,214219 -T AUTO -s ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/rescalediqtree/strategy1_2_rescaled/aftertrimnsqs_bialleliconly_filtered.min72.phy  -m MFP -B 1000 -alrt 1000 | tee -a ${wd}/phy/samples17_55_aftertrimnsqs/vcfandphy/rescalediqtree/iqtree.log

