seq 1 4 2004 > tmp1
seq 2 4 2004 > tmp11
seq 3 4 2004 > tmp111
seq 4 4 2004 > tmp1111
cat tmp1 tmp11 tmp111 tmp1111 > tmp10
#copy all 101-501 from 4 chains to one file
less 2004_1234.txt |cut -d ']' -f 2| cut -d ' ' -f 2 > tmp2

paste tmp10 tmp2 | sort -n   > merge_2004_1234.txt
