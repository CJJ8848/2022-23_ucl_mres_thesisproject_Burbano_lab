This folder contains the phylogenetic analysis pipelines and results. 

Two sub-folders:

Phylogenetic_read2tree contains the tree files of Arabidopsis thaliana and Pseudomonas derived from 200 and 500 OGs.

Phylogenetic_SNP contains the SNP matrix construction and tree inference of Pseudomonas (72/102), CFML recombination removal and bactdating dating analysis.



